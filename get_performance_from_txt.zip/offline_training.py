import os
import sys

os.system("nohup sh -c '" + sys.executable + " main.py' & echo $!")
# os.system("nohup sh -c '" + sys.executable + " main.py' > track_alpha_SIN.out & echo $!")
